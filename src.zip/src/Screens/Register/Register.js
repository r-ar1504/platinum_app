/*-----------------------------------------------------------------
* Default Components                                              |
*-----------------------------------------------------------------*/
import React, {Component} from 'react';
import { AppRegistry } from 'react-native';
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { Container, Header, Body, Left, Right, Content, Button } from 'native-base';
import { SafeAreaView, StyleSheet,StatusBar, ImageBackground, TouchableOpacity, TouchableWithoutFeedback, View, Text, Image, YellowBox, ActnativeivityIndicator, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import firebase from 'react-native-firebase';

/*-----------------------------------------------------------------
* Stylesheet                                                       |
*-----------------------------------------------------------------*/
import Style from './RegisterStyle';

/*-----------------------------------------------------------------
* Form Component                                                  |
*-----------------------------------------------------------------*/
import RegisterForm from './RegisterForm';

export default class Register extends Component{
  constructor(props){
    super(props);


    this.goBack = this.goBack.bind(this);
    this.handleRegister = this.handleRegister.bind(this);
    this.registerUser = this.registerUser.bind(this);    
  }//Constructor

  goBack(){
    this.props.navigation.pop();
  }

  handleRegister(credentials){

    firebase.auth().createUserAndRetrieveDataWithEmailAndPassword(credentials.email, credentials.password).then( response => {
      console.log(response)
      let registerData = {
        email: credentials.email,
        name: credentials.name,
        password: credentials.password,
        firebase_id: response.user.uid
      } 

        fetch('http://platinum-web.azurewebsites.net/api/addUserApp', {method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({        
            email: credentials.email,
            name: credentials.name,
            password: credentials.password,
            firebase_id: response.user.uid})
        })

      }).catch(function(error){
         if (error.code == "auth/invalid-email") {
          Alert.alert(
            'Platinum Times',
            "The email is not valid",
            [
              {text: 'Entendido', onPress: () => console.log('OK Pressed')},
            ],
            { cancelable: false }
          )
         }
         else if (error.code == "auth/email-already-in-use") {
          Alert.alert(
            'Platinum Times',
            "The email already exists",
            [
              {text: 'Entendido', onPress: () => console.log('OK Pressed')},
            ],
            { cancelable: false }
          )
         }
         else if (error.code == "auth/weak-password") {
          Alert.alert(
            'Platinum Times',
            "Password is not strong enough",
            [
              {text: 'Entendido', onPress: () => console.log('OK Pressed')},
            ],
            { cancelable: false }
          )
         }
      });


  }

  registerUser(credentials){

    fetch('http://platinum-web.azurewebsites.net/api/addUserApp', {method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(credentials)
    })
    .then((response) => response.json())
    .then((responseJson) => {
      return (responseJson);
      
      console.log(responseJson)
    })
  }

  render(){
    return(
      <SafeAreaView style={{ flex: 1, backgroundColor: '#fff'}}>
        <Container>
        <StatusBar hidden={true}/>
        <Header style={Style.header}>
          <Left>
            <TouchableWithoutFeedback onPress={this.goBack}>
              <View style={{marginTop: 15, marginLeft: 20}}>
                <Icon name="angle-left" color={'#000'} size={35} />
              </View>
            </TouchableWithoutFeedback>
          </Left>
          <Body>

          </Body>
          <Right>

          </Right>
        </Header>
        <Content contentContainerStyle={Style.container}>
          <Text style={Style.headerText}>
            REGISTER
          </Text>
          <RegisterForm  handleRegister={this.handleRegister}/>
        </Content>
      </Container>
      </SafeAreaView>
    )
  }//Render function.

}// Register component.
